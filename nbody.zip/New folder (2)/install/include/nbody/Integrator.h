#ifndef _NBODY_INTEGRATOR_H
#define _NBODY_INTEGRATOR_H
#include <nbody/System.h>
#include <nbody/Body.h>

namespace nbody{
	class Method{
	public:
		virtual void integrate(const Body &body, const float dt) = 0;
		virtual ~Method() {};
	};

	
	class INT :Integrator{
		Method _method;
	public:
		Integrator(Method method) :_method{ method }{}
	};
	
	class Integrator{
		enum{ INT };
	public:
		Integrator(System &_system){};
		void integrate(const System &system, const float dt);


	};

	

}



#endif // _NBODY_INTEGRATOR_H