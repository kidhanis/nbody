#include <nbody/Simulation.h>
#include "GlutWrapper.h"
#include "Shaders.h"

#include <glload/gl_3_0.h>
#include <glload/gll.hpp>
#include <GL/freeglut.h>

#include <iostream>
#include <fstream>
#include <cstdint>
#include <vector>
#include <algorithm>
#include <cmath>
int evolutions;
int allSize;
int steps;
float dt;
bool resetColors=false;
bool leaveTrail = false;
bool resetCount = false;
bool restartSimulation = false;
bool fixShape = false;
bool runBackwards = false;
bool stopRun = false;
namespace nBodyShaders {

  const std::string vertex1(
    "#version 130\n"
    "in vec4 position;\n"
    "void main()\n"
    "{\n"
    "   gl_Position = position;\n"
    "}\n"
  );

  const std::string fragment1(
    "#version 130\n"
    "out vec4 outputColor;\n"
    "void main()\n"
    "{\n"
    "   outputColor = vec4(1.0f,1.0f,1.0f,1.0f);"
    "}\n"
  );
} // namespace shaders

class NBodyWindow : public GlutWrapper {
public:
	NBodyWindow( const std::string &title, 
               Mode debugMode = Mode::NDEBUG );
  ~NBodyWindow();

  void display();
  void reshape( int theWidth, int theHeight );
  void keyboard( unsigned char key, int x, int y );
};

NBodyWindow::NBodyWindow( const std::string &title, Mode debugMode ) : 
GlutWrapper{ title, debugMode } {
	_instance = this;
}

NBodyWindow::~NBodyWindow() {}

void NBodyWindow::reshape( int theWidth, int theHeight ) { 
	glViewport( 0, 0, (GLsizei) theWidth, (GLsizei) theHeight );
}

void NBodyWindow::keyboard(unsigned char key, int /*x*/, int /*y*/) {
	const char BACKSPACE = 8;
	const char ESCAPE_KEY = 27;
	const char SPACEBAR = 32;
	const char A_KEY = 65;
	const char D_KEY = 68;
	const char R_KEY = 82;
	const char T_KEY = 84;

	if (key == A_KEY){
		runBackwards = true;
		resetColors = true;
		glClear(GL_COLOR_BUFFER_BIT);
		glutSwapBuffers();
	}
	else if (key == D_KEY){
		runBackwards = false;
		resetColors = true;
		glClear(GL_COLOR_BUFFER_BIT);
		glutSwapBuffers();
	}
	else if (key == SPACEBAR){
		if (stopRun){
			stopRun = false;
		}
		else{
			stopRun = true;
		}
	}
	
	else if (key == R_KEY){
		resetColors = true;
		glClear(GL_COLOR_BUFFER_BIT);
		glutSwapBuffers();
	}
	else if (key == T_KEY) {
		if (leaveTrail){
			leaveTrail = false;
		}
		else{ leaveTrail = true; }
	}
	
	else if (key == BACKSPACE){
		resetCount = true;;
		fixShape = true;
		resetColors = true;
		leaveTrail = false;
	}
	else if (key == ESCAPE_KEY) {
		glutLeaveMainLoop();
	}
}

int theCount = 0;
float scale = 0.0f;

void NBodyWindow::display() {
	float max = 0.0;
	for (size_t i = 0; i < _bufSize / 4; ++i) {
		for (size_t j = 0; j<4; ++j){
			float temp = fabsf(_all[(_bufSize*theCount + i * 4 + j)]);
			if (temp>max){
				max = temp;
			}
		}
	}
	if (max>scale || scale==0){
		scale = max;
	}
	for (size_t i = 0; i < _bufSize / 4; ++i) {
		_buf[4 * i] = _all[(_bufSize* theCount + i * 4) % allSize] / scale;
		_buf[4 * i + 1] = _all[(_bufSize*theCount + i * 4 + 1) % allSize] /scale;
		_buf[4 * i + 2] = _all[(_bufSize*theCount + i * 4 + 2) % allSize] / scale;
		_buf[4 * i + 3] = 1.0f;
	}
	if (theCount < evolutions*steps){
		if (!stopRun){
			if (runBackwards){
				theCount -= 1;
				if (theCount == 0){
					runBackwards = false;
				}
			}
			else{
				theCount++;
			}
		}
	}
	else{
		glutLeaveMainLoop();
	}
	
	glBindBuffer(GL_ARRAY_BUFFER, _positionBufferObject);
	glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(float)* _bufSize, _buf);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	if (resetCount){
		theCount = 0;
		resetCount = false;
	}
	if (fixShape){
		reshape(_width, _height);
		fixShape = false;
	}
	if (!leaveTrail){
		glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
		glClear(GL_COLOR_BUFFER_BIT);
	}

	glUseProgram(_program);
	glBindBuffer(GL_ARRAY_BUFFER, _positionBufferObject);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, 0); 
	glDrawArrays(GL_POINTS, 0, (GLsizei)_bufSize);
	glPointSize(5);
	glDisableVertexAttribArray(0);
	glUseProgram(0);

	if (resetColors){
		glClear(GL_COLOR_BUFFER_BIT);
	}
	resetColors = false;
	glutSwapBuffers();
	glutPostRedisplay();
}

int main(int argc, char **argv) {
	size_t N = 3;
	steps = 1e3;
	dt = 0.00001;
	evolutions = 70;
	size_t bufSize = 4 * N;
	allSize = bufSize * evolutions*steps;
	float *all = new float[allSize];
	try {
		std::ifstream input{ "resources/nbody/binary-system-simple.txt" };
		nbody::Simulation sim{ input };
		for (int i = 0; i < evolutions; ++i) {
			sim.saveRun();
			sim.evolveSystem(steps, dt, all, i);
		}
		sim.saveRun();
	}
	catch (const std::exception &e) {
		std::cerr << "Error: " << e.what() << "\n";
	}
  try {
		float *buf = new float[bufSize*evolutions*steps];

		Shaders shaders;
		shaders.addToVertexList( nBodyShaders::vertex1 ); 
		shaders.addToFragmentList( nBodyShaders::fragment1 );
    NBodyWindow window{ "N-Body Simulation", GlutWrapper::NDEBUG };
		window.init( argc, argv, 500, 500, &shaders,all, bufSize, buf );
		window.run();
		delete[] all;
    return 0;
  } catch( const std::exception &e ) {
    std::cerr << "Error: " << e.what() << "\n";
    return 1;
  }
}

