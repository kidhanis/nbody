/** Copyright (C) 2011 by Jason L. McKesson **/
/** This file is licensed by the MIT License. **/



#ifndef GLSDK_MESH_GENERATOR_DESCRIPTORS_H
#define GLSDK_MESH_GENERATOR_DESCRIPTORS_H

/**
\file
\brief Describes the mesh generator flags.

**/

namespace glmesh
{
}




#endif //GLSDK_MESH_GENERATOR_DESCRIPTORS_H
