#ifndef WGLL_EXT_H
#define WGLL_EXT_H


#include "gll_util.h"

#ifdef __cplusplus
extern "C" {
#endif //__cplusplus



extern StrToExtMap wgleIntExtensionMap[];
extern int wgleIntExtensionMapSize;

void wgleIntClear();


#ifdef __cplusplus
}
#endif //__cplusplus


#endif //WGLL_EXT_H

