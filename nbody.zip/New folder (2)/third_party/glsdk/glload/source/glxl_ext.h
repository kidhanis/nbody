#ifndef GLXL_EXT_H
#define GLXL_EXT_H


#include "gll_util.h"

#ifdef __cplusplus
extern "C" {
#endif //__cplusplus



extern StrToExtMap glXeIntExtensionMap[];
extern int glXeIntExtensionMapSize;

void glXeIntClear();


#ifdef __cplusplus
}
#endif //__cplusplus


#endif //GLXL_EXT_H

