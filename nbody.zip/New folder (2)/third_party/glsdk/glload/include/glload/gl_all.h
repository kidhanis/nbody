/** Copyright (C) 2011 by Jason L. McKesson **/
/** This file is licensed by the MIT License. **/


#ifndef GLLOAD_GL_ALL_H
#define GLLOAD_GL_ALL_H

#include "gl_4_2_comp.h"



#endif //GLLOAD_GL_ALL_H
