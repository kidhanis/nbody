#ifndef _INT_GL_3_0_REM_3_1_H
#define _INT_GL_3_0_REM_3_1_H



#ifdef __cplusplus
extern "C" {
#endif //__cplusplus


#define GL_CLAMP_VERTEX_COLOR 0x891A
#define GL_CLAMP_FRAGMENT_COLOR 0x891B
#define GL_ALPHA_INTEGER 0x8D97



#ifdef __cplusplus
}
#endif //__cplusplus


#endif //_INT_GL_3_0_REM_3_1_H

