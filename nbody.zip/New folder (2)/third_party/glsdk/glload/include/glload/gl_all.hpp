//Copyright (C) 2011 by Jason L. McKesson
//This file is licensed by the MIT License.


#ifndef GLLOAD_GL_ALL_HPP
#define GLLOAD_GL_ALL_HPP

#include "gl_4_2_comp.hpp"



#endif //GLLOAD_GL_ALL_HPP
