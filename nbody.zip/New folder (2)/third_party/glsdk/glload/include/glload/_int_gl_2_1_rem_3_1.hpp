#ifndef _INT_GL_2_1_REM_3_1_HPP
#define _INT_GL_2_1_REM_3_1_HPP



#ifdef __cplusplus
extern "C" {
#endif //__cplusplus


#ifdef __cplusplus
}
#endif //__cplusplus



namespace gl
{
	enum _int_gl_2_1_rem_3_1
	{
		GL_CURRENT_RASTER_SECONDARY_COLOR = 0x845F,
		GL_SLUMINANCE_ALPHA              = 0x8C44,
		GL_SLUMINANCE8_ALPHA8            = 0x8C45,
		GL_SLUMINANCE                    = 0x8C46,
		GL_SLUMINANCE8                   = 0x8C47,
		GL_COMPRESSED_SLUMINANCE         = 0x8C4A,
		GL_COMPRESSED_SLUMINANCE_ALPHA   = 0x8C4B,
	};


}

#endif //_INT_GL_2_1_REM_3_1_HPP

