#ifndef _INT_GL_3_0_REM_3_1_HPP
#define _INT_GL_3_0_REM_3_1_HPP



#ifdef __cplusplus
extern "C" {
#endif //__cplusplus


#ifdef __cplusplus
}
#endif //__cplusplus



namespace gl
{
	enum _int_gl_3_0_rem_3_1
	{
		GL_CLAMP_VERTEX_COLOR            = 0x891A,
		GL_CLAMP_FRAGMENT_COLOR          = 0x891B,
		GL_ALPHA_INTEGER                 = 0x8D97,
	};


}

#endif //_INT_GL_3_0_REM_3_1_HPP

